-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2024 at 06:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olfdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `combo`
--

CREATE TABLE `combo` (
  `prodid` int(11) NOT NULL,
  `color` varchar(32) NOT NULL,
  `size` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `combo`
--

INSERT INTO `combo` (`prodid`, `color`, `size`) VALUES
(5, 'beige', 'l'),
(5, 'beige', 'm'),
(5, 'beige', 'xl'),
(4, 'blue', 'W36-L38'),
(4, 'blue', 'W38-L38'),
(4, 'blue', 'W38-L40'),
(4, 'blue', 'W38-L42'),
(4, 'blue', 'W40-L38'),
(4, 'blue', 'W40-L40'),
(4, 'blue', 'W40-L42'),
(4, 'blue', 'W42-L38'),
(4, 'blue', 'W42-L40'),
(4, 'blue', 'W42-L42'),
(2, 'green', 'l'),
(2, 'green', 'm'),
(1, 'lightblue', 'l'),
(1, 'lightblue', 'm'),
(1, 'lightblue', 's'),
(1, 'lightblue', 'xl'),
(1, 'white', 'l'),
(1, 'white', 'm'),
(1, 'white', 's'),
(1, 'white', 'xl'),
(1, 'white', 'xxl');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `adress` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `phone` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `adress`, `email`, `phone`) VALUES
(2, 'Andersson', 'Sveavägen 2', 'mdalmdal', '11211212'),
(3, 'Bert Bertillsson', 'storgatan 32', 'bigbert@gmail.com', '502'),
(4, 'Andersson', 'nogonstans', 'dasdf', 'asdasd'),
(5, 'Adam', 'Adamvägen', 'adam@gmail.com', '0707-123234'),
(6, 'Adam', 'Adamvägen', 'adam@gmail.com', '0707-123234'),
(7, 'Bertil', 'Bertvägen', 'bert@gmail.com', '0707-232345'),
(8, 'Cesar', 'Cecarvägen', 'cecar@gmail.com', '0707-323456'),
(9, 'David', 'Davidvägen', 'david@gmail.com', '0707-523234');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `returnid` int(11) NOT NULL,
  `edate` date NOT NULL,
  `action` varchar(128) NOT NULL,
  `event` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `returnid`, `edate`, `action`, `event`) VALUES
(1, 1, '2024-02-03', 'Replacement accepted. Initiate replacement order when product is returned.', 'Wrong size, offered customer to send a replacement in correct size');

-- --------------------------------------------------------

--
-- Table structure for table `inhouse`
--

CREATE TABLE `inhouse` (
  `id` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `color` varchar(32) NOT NULL,
  `size` varchar(32) NOT NULL,
  `shelfsid` int(11) NOT NULL,
  `shellnr` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `prodstatus` enum('Expected_delivery','Out_of_date','Return_to_supplier','None','Product_failure','Returned') NOT NULL,
  `orderpoint` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inhouse`
--

INSERT INTO `inhouse` (`id`, `prodid`, `color`, `size`, `shelfsid`, `shellnr`, `slot`, `quantity`, `prodstatus`, `orderpoint`) VALUES
(1, 1, 'white', 'm', 1, 1, 2, 20, 'None', 10),
(2, 1, 'white', 'm', 1, 1, 3, 30, 'None', 20),
(3, 4, 'blue', 'W38-L38', 2, 1, 3, 30, '', 20);

-- --------------------------------------------------------

--
-- Table structure for table `orderrows`
--

CREATE TABLE `orderrows` (
  `id` int(11) NOT NULL,
  `ordernr` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `color` varchar(32) NOT NULL,
  `size` varchar(32) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float NOT NULL,
  `delivquant` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderrows`
--

INSERT INTO `orderrows` (`id`, `ordernr`, `productid`, `color`, `size`, `quantity`, `price`, `delivquant`) VALUES
(1, 1, 2, 'white', 's', 3, 59.99, 0),
(2, 1, 5, 'beige', 'l', 1, 32.99, 0),
(3, 3, 1, 'lightblue', 'm', 1, 1249.99, 1),
(4, 3, 1, 'white', 'm', 2, 105.99, 0),
(5, 7, 5, 'beige', 'l', 1, 237.49, 0),
(6, 7, 2, 'green', 'l', 1, 84.49, 1),
(7, 8, 1, 'white', 'l', 1, 79.99, 0),
(8, 9, 5, 'beige', 'l', 1, 237.49, 0),
(9, 9, 2, 'green', 'l', 2, 84.49, 0),
(10, 9, 1, 'lightblue', 'l', 1, 79.99, 0),
(11, 9, 1, 'white', 'l', 1, 79.99, 0),
(12, 10, 4, 'white', 'm', 2, 329.99, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `odate` date NOT NULL,
  `status` enum('recieved','split_delivery','deliver_one_go','invoice_sent','delivered') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customerid`, `odate`, `status`) VALUES
(1, 2, '2024-01-23', 'recieved'),
(3, 2, '2024-01-29', 'split_delivery'),
(4, 4, '2024-01-31', 'recieved'),
(6, 4, '2024-02-01', 'recieved'),
(7, 4, '2024-02-01', 'recieved'),
(8, 4, '2024-02-01', 'recieved'),
(9, 4, '2024-02-03', 'recieved'),
(10, 5, '2024-01-23', 'invoice_sent');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(63) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`) VALUES
(1, 'T-shirt, round neck', 79.99),
(2, 'T-shirt, v-neck', 84.49),
(3, 'Tie, silk', 139.99),
(4, 'Trousers, jeans tiptop', 329.99),
(5, 'Sweatshirt - wool ', 237.49),
(6, 'Sweatshirt - college style ', 259.99),
(7, 'Socks, 3 pairs package', 156.59);

-- --------------------------------------------------------

--
-- Table structure for table `returns`
--

CREATE TABLE `returns` (
  `id` int(11) NOT NULL,
  `ordernr` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `color` varchar(64) NOT NULL,
  `size` varchar(64) NOT NULL,
  `status` enum('used_as_new','repair','return_supplier','used_minor_fault') NOT NULL,
  `desciption` varchar(128) NOT NULL,
  `est-value` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returns`
--

INSERT INTO `returns` (`id`, `ordernr`, `prodid`, `color`, `size`, `status`, `desciption`, `est-value`) VALUES
(1, 7, 4, 'green', 'l', 'used_as_new', 'Wrong size', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shelfs`
--

CREATE TABLE `shelfs` (
  `id` int(11) NOT NULL,
  `place` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shelfs`
--

INSERT INTO `shelfs` (`id`, `place`) VALUES
(1, '1 Hall A'),
(2, '2 Hall A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `combo`
--
ALTER TABLE `combo`
  ADD PRIMARY KEY (`color`,`prodid`,`size`) USING BTREE;

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inhouse`
--
ALTER TABLE `inhouse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderrows`
--
ALTER TABLE `orderrows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shelfs`
--
ALTER TABLE `shelfs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inhouse`
--
ALTER TABLE `inhouse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orderrows`
--
ALTER TABLE `orderrows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `returns`
--
ALTER TABLE `returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shelfs`
--
ALTER TABLE `shelfs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
